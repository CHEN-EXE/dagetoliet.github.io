<?PHP
// 看啥
$nb = $_GET["tar"];
echo "登录用户:".$nb;
session_start();
?>