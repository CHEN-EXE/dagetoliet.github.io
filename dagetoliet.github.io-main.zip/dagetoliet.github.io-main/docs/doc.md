# 大哥国际，走向全成。
<img alt="Static Badge" src="https://img.shields.io/badge/大哥国际厕所集团">

该文档介绍了我司的产品项目清单，以及各项目使用方法。
Group.DageGuoJIToliet.CoLtd.
## <svg xmlns="http://www.w3.org/2000/svg" width="70" height="70" viewBox="0 0 24 24"><path fill="none" stroke="#000" d="M5.5 8v7.5h.25s1.016-1.152 1.5-2c.62-1.087 1.125-2.5 1.125-2.5h.25s.505 1.413 1.125 2.5c.484.848 1.5 2 1.5 2h.25V8m7 2.5v-1a1 1 0 0 0-1-1H15a1 1 0 0 0-1 1v5a1 1 0 0 0 1 1h2.5a1 1 0 0 0 1-1v-1m-6.5 10C5.649 23.5.5 18.351.5 12S5.649.5 12 .5S23.5 5.649 23.5 12S18.351 23.5 12 23.5Z"/></svg>Toliet
Toliet VIP是一款针对于公共厕所收费的系统，该系统有着强制性合盖的特点，解决了占坑不拉屎的
<button>立即下载</button>
## TolietAds
这是一款能够在厕所墙上大屏渲染的广告程序，薄利多销，分发广告，创造收益。
### 虚构 请勿当真