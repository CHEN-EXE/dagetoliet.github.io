# Toliet
## Toliet是一款针对于公共厕所收费的系统，该系统有着强制性合盖的特点，解决了占坑不拉屎的
## 启动伪服务（html）
> 下载/toliet/index.html
## 启动伪服务（LinuxShell）
> 下载/toliet/main.sh
<br>执行 sh main.sh
<br>显示伪登录页面。
<br>
```txt
欢迎使用厕所收费服务
大哥国际厕所公司开发 仅供娱乐 请勿当真
Linux localhost
------------------------

请扫码登录
二维码：加载失败
模拟登录请输入：LocalLogin
```
<br>
<img alt="Static Badge" src="https://img.shields.io/badge/仅作娱乐，请勿当真！-3">
### 该程序不能够实现厕所收费功能，仅供娱乐，请勿当真。
